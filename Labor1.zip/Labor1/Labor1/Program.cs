﻿int sum = 5 + 3;
int result = 7 - 2;
Console.WriteLine(sum);


